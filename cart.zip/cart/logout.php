<?php
session_start();
session_destroy();
?>
  		<script type="text/javascript">
			alert("You've been Logout!");
			window.location = "login.php";
		</script>

  <?php 
